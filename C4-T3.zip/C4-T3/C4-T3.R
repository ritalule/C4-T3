library(ggplot2)
library(e1071)
library(caret)
library(corrplot)
library(readr)
library(splines)
library(gbm)
library(plyr)
library(dplyr)
library(C50)
library(parallel)
library(foreach)
library(iterators)
library(doParallel)

install.packages("foreach")
## Import Data
trainingData <- read.csv("~/Course 4/trainingData.csv")
View(trainingData)
summary(trainingData)
str(trainingData)
save.image()

attributes(trainingData)


# select variables v1, v2, v3
myvars <- trainingData[c(1:520,523:526)]
newdata <- (myvars)
summary(newdata)
str(newdata)
attributes(newdata)

View(newdata)


# based on variable values
building1 <- newdata[ which(newdata$BUILDINGID==1),]
View(building1)
str(building1)
save.image()

## combine the new attributes into a new attribute column
building1 <- cbind(building1, paste(building1$BUILDINGID, building1$FLOOR,building1$SPACEID,building1$RELATIVEPOSITION), stringsAsFactors = TRUE)

## change column name
colnames(building1)[525] <- 'LocationID'
str(building1)
summary(building1)
building1$LocationID <- as.factor(building1$LocationID)
building1 <- droplevels(building1)
building1 <- na.omit(building1)

#NearZeroVar Test and Removal of Zero Var Predictors
#df_1
nzv1 <- nearZeroVar(building1, saveMetrics = TRUE)
head(nzv1)
summary(nzv1) #table: attributes can be removed for zero variance
zeroVarData1 <- which(nzv1$zeroVar == T)
zeroVarData1 #list of zero var predicters
building1 <- building1[,-(zeroVarData1)] # remove each observation from the list
str(building1)
#create as factor
building1$LocationID <- as.factor(building1$LocationID)
str(building1)
summary(building1)
building1$BUILDINGID

building1 <- building1[c(1:207,211)]
save.image()

set.seed(998)
trainSize<-round(nrow(building1)*0.75) 
testSize<-nrow(building1)-trainSize

droplevels(building1)


training_indices<-sample(seq_len(nrow(building1)),size =trainSize)
trainSet<-building1[training_indices,]
testSet<-building1[-training_indices,] 

inTraining <- createDataPartition(building1$LocationID, p=.75, list=FALSE)

training <- building1[inTraining,]
testing <- building1[-inTraining,]

training
testing
droplevels(training)


fitControl <- trainControl(method = "repeatedcv", number = 10, repeats = 1)

detectCores()
cl <- makeCluster(2)
registerDoParallel(cl)
getDoParWorkers()
stopCluster(cl)

RF_LocationID <- train(LocationID~., data = training, method = "rf", trControl=fitControl)
c5_LocationID <- train(LocationID ~., data = training, method = "C5.0",trControl = fitControl)
knn_LocationID <- train(LocationID~., data=training, method="knn",trControl=fitControl)


RF_LocationID

c5_LocationID

knn_LocationID

ModelData <- resamples(list(rf = RF_LocationID, C5.0 = c5_LocationID, knn=knn_LocationID))
Summary(ModelData)



predc5_LocationID <- predict(c5_LocationID, testing)
predc5_LocationID
postResample(predc5_LocationID, testing$LocationID)
confusionMatrix(testing$LocationID, predc5_LocationID)


PredRF_LocationID <- predict(RF_LocationID, testing)
PredRF_LocationID
postResample(PredRF_LocationID, testing$LocationID)
confusionMatrix(testing$LocationID, PredRF_LocationID)

save.image()

Predknn_LocationID <- predict(knn_LocationID, testing)
Predknn_LocationID
postResample(Predknn_LocationID, testing$LocationID)
confusionMatrix(testing$LocationID, Predknn_LocationID)

